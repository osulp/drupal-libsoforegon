window.tinyMCEPreInit = {"base":"\/~etskenna\/drupal_loo\/sites\/all\/libraries\/tinymce\/jscripts\/tiny_mce","suffix":"","query":""};;
